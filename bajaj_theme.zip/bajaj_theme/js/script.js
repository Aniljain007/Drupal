// alert("Hi anil");

// const hamMenu = document.querySelector('.ham-menuu');
 
//  const offScreenMenu = document.querySelector('.off-screen-menu');
 
//  hamMenu.addEventListener('click', () => {
//     hamMenu.class.List.toggle('active');
//     offScreenMenu.classList.toggle('active');
//  })

// function myFunction(){
//     var x= document.getElementById("mobilemenutoggle");
//     document.getElementsByClassName("gds-search__input").innerHTML= "You are searching for: " + x.value;
// }

// const search = document.querySelector('.gds-search')
// const btn = document.querySelector('#mobilemenutoggle')
// const input = document.querySelector('.gds-search__input')
// btn.addEventListener('click', (event) => {
// search.classList.toggle('active')
// input.focus()
// event.preventDefault();
// })

// const search = document.querySelector('.search')
// const btn = document.querySelector('.btn')
// const input = document.querySelector('.input')
// btn.addEventListener('click', () => {
// search.classList.toggle('active')
// input.focus()
// })

// alert("hi");